import 'package:flutter/material.dart';
import 'prayer_request_screen.dart';

class PrayersScreen extends StatelessWidget {
  const PrayersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('Prayer & Word', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          const SizedBox(height: 18),
          Card(
            elevation: 0,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('Gospel Reflection', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 12),
                  Text(
                    'Use this section for the daily Gospel, reflection, liturgical calendar and parish prayer resources.',
                    style: TextStyle(height: 1.5),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            elevation: 0,
            child: ListTile(
              leading: const Icon(Icons.menu_book, color: Color(0xFF7B1E2B)),
              title: const Text('Daily Gospel'),
              subtitle: const Text('Connect this section to your preferred Catholic readings source.'),
            ),
          ),
          Card(
            elevation: 0,
            child: ListTile(
              leading: const Icon(Icons.favorite_outline, color: Color(0xFF7B1E2B)),
              title: const Text('Rosary & Prayers'),
              subtitle: const Text('Store parish prayer resources here.'),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrayerRequestScreen())),
            icon: const Icon(Icons.volunteer_activism),
            label: const Text('Submit a Prayer Request'),
          ),
        ],
      ),
    );
  }
}
