import 'package:flutter/material.dart';
import '../services/app_repository.dart';

class EventsScreen extends StatelessWidget {
  const EventsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final events = AppRepository().getEvents();
    return Scaffold(
      appBar: AppBar(title: const Text('Parish Events')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: events.length,
        itemBuilder: (_, index) {
          final e = events[index];
          return Card(
            elevation: 0,
            margin: const EdgeInsets.only(bottom: 14),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(e.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('${e.date} • ${e.time}', style: const TextStyle(color: Color(0xFF7B1E2B), fontWeight: FontWeight.w600)),
                  const SizedBox(height: 5),
                  Text(e.location),
                  const SizedBox(height: 10),
                  Text(e.description),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
