import 'package:flutter/material.dart';
import '../services/app_repository.dart';

class AppointmentScreen extends StatefulWidget {
  const AppointmentScreen({super.key});

  @override
  State<AppointmentScreen> createState() => _AppointmentScreenState();
}

class _AppointmentScreenState extends State<AppointmentScreen> {
  final formKey = GlobalKey<FormState>();
  final purpose = TextEditingController();
  DateTime? date;
  TimeOfDay? time;

  @override
  void dispose() {
    purpose.dispose();
    super.dispose();
  }

  Future<void> chooseDate() async {
    final selected = await showDatePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 180)),
      initialDate: DateTime.now(),
    );
    if (selected != null) setState(() => date = selected);
  }

  Future<void> chooseTime() async {
    final selected = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (selected != null) setState(() => time = selected);
  }

  void submit() {
    if (!formKey.currentState!.validate() || date == null || time == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please complete all appointment fields.')),
      );
      return;
    }
    AppRepository().submitAppointment(
      purpose.text.trim(),
      '${date!.day}/${date!.month}/${date!.year}',
      time!.format(context),
    );
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Appointment request submitted.')),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Priest Appointment')),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const Text('Request a Meeting', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 18),
            TextFormField(
              controller: purpose,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Purpose of meeting'),
              validator: (v) => v == null || v.trim().isEmpty ? 'Enter the purpose.' : null,
            ),
            const SizedBox(height: 14),
            OutlinedButton.icon(
              onPressed: chooseDate,
              icon: const Icon(Icons.calendar_today),
              label: Text(date == null ? 'Choose date' : '${date!.day}/${date!.month}/${date!.year}'),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: chooseTime,
              icon: const Icon(Icons.access_time),
              label: Text(time == null ? 'Choose time' : time!.format(context)),
            ),
            const SizedBox(height: 20),
            FilledButton(onPressed: submit, child: const Text('Submit Appointment')),
          ],
        ),
      ),
    );
  }
}
