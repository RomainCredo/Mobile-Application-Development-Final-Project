import 'package:flutter/material.dart';

const primaryBlue = Color(0xFF1E88E5);
const lightBlueBg = Color(0xFFE3F2FD);
const cardBlueBg = Color(0xFFF0F7FF);

class CommunityScreen extends StatelessWidget {
  const CommunityScreen({super.key});

  final List<Map<String, String>> _communities = const [
    {
      'name': 'Umuryango Remezo St. Kizito',
      'zone': 'Central Zone • Musanze',
      'leader': 'Jean-Baptiste H.',
      'meeting': 'Thursdays at 05:00 PM',
      'members': '28 Families',
    },
    {
      'name': 'Umuryango Remezo Bikira Mariya',
      'zone': 'North Zone',
      'leader': 'Marie Gorette U.',
      'meeting': 'Wednesdays at 06:00 PM',
      'members': '34 Families',
    },
    {
      'name': 'Umuryango Remezo St. Joseph',
      'zone': 'East Zone',
      'leader': 'Paul K.',
      'meeting': 'Tuesdays at 05:30 PM',
      'members': '22 Families',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Imiryango Remezo', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _communities.length,
        itemBuilder: (context, index) {
          final c = _communities[index];
          return Container(
            margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardBlueBg,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: lightBlueBg, width: 1.5),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(c['name']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: primaryBlue)),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(color: lightBlueBg, borderRadius: BorderRadius.circular(8)),
                      child: Text(c['members']!, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: primaryBlue)),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(c['zone']!, style: const TextStyle(color: Colors.grey, fontSize: 13)),
                const Divider(height: 20),
                Row(
                  children: [
                    const Icon(Icons.person_pin, size: 18, color: primaryBlue),
                    const SizedBox(width: 8),
                    Text('Leader: ${c['leader']}', style: const TextStyle(fontSize: 13)),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(Icons.event, size: 18, color: primaryBlue),
                    const SizedBox(width: 8),
                    Text('Gatherings: ${c['meeting']}', style: const TextStyle(fontSize: 13)),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}