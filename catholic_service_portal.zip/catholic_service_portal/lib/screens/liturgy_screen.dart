import 'package:flutter/material.dart';
import '../services/language_service.dart';

const primaryBlue = Color(0xFF1E88E5);
const lightBlueBg = Color(0xFFE3F2FD);
const cardBlueBg = Color(0xFFF0F7FF);

class LiturgyScreen extends StatefulWidget {
  const LiturgyScreen({super.key});

  @override
  State<LiturgyScreen> createState() => _LiturgyScreenState();
}

class _LiturgyScreenState extends State<LiturgyScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: LanguageService.instance.currentLanguage,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            title: const Text(
              'Daily Readings & Liturgy',
              style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
            ),
            backgroundColor: Colors.white,
            elevation: 0,
            bottom: TabBar(
              controller: _tabController,
              labelColor: primaryBlue,
              unselectedLabelColor: Colors.grey,
              indicatorColor: primaryBlue,
              tabs: const [
                Tab(icon: Icon(Icons.menu_book), text: "Daily Readings"),
                Tab(icon: Icon(Icons.calendar_month), text: "Liturgical Calendar"),
              ],
            ),
          ),
          body: TabBarView(
            controller: _tabController,
            children: [
              _buildReadingsTab(),
              _buildCalendarTab(),
            ],
          ),
        );
      },
    );
  }

  Widget _buildReadingsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF2E7D32), Color(0xFF4CAF50)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                const CircleAvatar(
                  backgroundColor: Colors.white24,
                  child: Icon(Icons.auto_awesome, color: Colors.white),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Ordinary Time — Tuesday',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      Text(
                        'October 6, 2026 • Liturgical Color: Green',
                        style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 13),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _buildReadingCard(
            title: 'First Reading',
            citation: 'Galatians 1:13-24',
            content:
                'Brothers and sisters: You heard of my former way of life in Judaism, how I persecuted the church of God beyond measure and tried to destroy it, and progressed in Judaism beyond many of my contemporaries among my race...',
          ),
          const SizedBox(height: 16),
          _buildReadingCard(
            title: 'Responsorial Psalm',
            citation: 'Psalm 139:1b-3, 13-14ab, 14c-15',
            response: 'R. Guide me, Lord, along the everlasting way.',
            content:
                'O LORD, you have probed me and you know me; you know when I sit and when I stand; you understand my thoughts from afar. My journeys and my rest you scrutinize, with all my ways you are familiar.',
          ),
          const SizedBox(height: 16),
          _buildReadingCard(
            title: 'Gospel',
            citation: 'Luke 10:38-42',
            content:
                'Jesus entered a village where a woman whose name was Martha welcomed him. She had a sister named Mary who sat beside the Lord’s feet listening to his speaking. Martha, burdened with much serving, came to him and said, "Lord, do you not care that my sister has left me by myself to do the serving? Tell her to help me." The Lord said to her in reply, "Martha, Martha, you are anxious and worried about many things..."',
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _buildReadingCard({
    required String title,
    required String citation,
    String? response,
    required String content,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: cardBlueBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: lightBlueBg, width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: primaryBlue),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: lightBlueBg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  citation,
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: primaryBlue),
                ),
              ),
            ],
          ),
          if (response != null) ...[
            const SizedBox(height: 10),
            Text(
              response,
              style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black87, fontSize: 14),
            ),
          ],
          const SizedBox(height: 10),
          Text(
            content,
            style: const TextStyle(fontSize: 14, height: 1.5, color: Colors.black87),
          ),
        ],
      ),
    );
  }

  Widget _buildCalendarTab() {
    final upcomingFeasts = [
      {'date': 'Oct 7', 'title': 'Our Lady of the Rosary', 'type': 'Memorial', 'color': Colors.amber.shade700},
      {'date': 'Oct 15', 'title': 'St. Teresa of Jesus', 'type': 'Memorial', 'color': Colors.redAccent},
      {'date': 'Oct 18', 'title': 'St. Luke, Evangelist', 'type': 'Feast', 'color': Colors.red.shade700},
      {'date': 'Nov 1', 'title': 'All Saints Day', 'type': 'Solemnity', 'color': Colors.amber.shade800},
      {'date': 'Nov 2', 'title': 'All Souls Day', 'type': 'Commemoration', 'color': Colors.purple.shade700},
    ];

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: upcomingFeasts.length,
      itemBuilder: (context, index) {
        final feast = upcomingFeasts[index];
        return Card(
          elevation: 0,
          color: cardBlueBg,
          margin: const EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: const BorderSide(color: lightBlueBg, width: 1.5),
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            leading: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: lightBlueBg,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                feast['date'] as String,
                style: const TextStyle(fontWeight: FontWeight.bold, color: primaryBlue, fontSize: 13),
              ),
            ),
            title: Text(
              feast['title'] as String,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
            subtitle: Row(
              children: [
                Icon(Icons.brightness_1, size: 10, color: feast['color'] as Color),
                const SizedBox(width: 6),
                Text(feast['type'] as String, style: const TextStyle(fontSize: 12)),
              ],
            ),
          ),
        );
      },
    );
  }
}