import 'package:flutter/material.dart';
import '../models/app_models.dart';
import '../services/app_repository.dart';
import '../services/language_service.dart';

const primaryBlue = Color(0xFF1E88E5);
const lightBlueBg = Color(0xFFE3F2FD);
const cardBlueBg = Color(0xFFF0F7FF);

class GroupsScreen extends StatefulWidget {
  const GroupsScreen({super.key});

  @override
  State<GroupsScreen> createState() => _GroupsScreenState();
}

class _GroupsScreenState extends State<GroupsScreen> {
  final AppRepository _repository = AppRepository();
  static final Set<String> _joinedGroupIds = {};

  // Mock group activity updates
  final Map<String, List<Map<String, String>>> _groupActivities = {
    '1': [
      {
        'title': 'Rehearsal Scheduled',
        'date': 'Tomorrow at 05:00 PM',
        'desc': 'Preparing hymns for this coming Sunday’s 09:00 AM Mass in the main choir room.'
      },
      {
        'title': 'New Sheet Music Available',
        'date': 'Oct 4, 2026',
        'desc': 'Downloaded materials for the offertory song are ready in the group drive.'
      },
    ],
    '2': [
      {
        'title': 'Monthly Charity Drive',
        'date': 'This Saturday at 09:00 AM',
        'desc': 'Food distribution setup at the parish hall. All volunteers welcome.'
      },
    ],
    '3': [
      {
        'title': 'Youth Prayer Night',
        'date': 'Friday at 06:00 PM',
        'desc': 'Adoration and fellowship session in St. Joseph chapel.'
      },
    ],
  };

  void _showGroupDetailsModal(ChurchGroup group) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            final bool isJoined = _joinedGroupIds.contains(group.id);
            final activities = _groupActivities[group.id] ?? [
              {
                'title': 'Welcome New Members!',
                'date': 'Recently',
                'desc': 'Stay tuned for upcoming events and updates from group leaders.'
              }
            ];

            return Container(
              constraints: BoxConstraints(
                maxHeight: MediaQuery.of(context).size.height * 0.85,
              ),
              padding: const EdgeInsets.all(24.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Group Header
                    Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: isJoined ? primaryBlue : lightBlueBg,
                          radius: 24,
                          child: Icon(
                            isJoined ? Icons.check : Icons.groups,
                            color: isJoined ? Colors.white : primaryBlue,
                            size: 28,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                group.name,
                                style: const TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87,
                                ),
                              ),
                              Text(
                                group.meeting,
                                style: const TextStyle(
                                  color: primaryBlue,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 30),

                    // About Section
                    const Text(
                      'About this Group',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      group.description,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.black.withOpacity(0.7),
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Meeting Schedule
                    const Text(
                      'Meeting Schedule',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.access_time, size: 18, color: Colors.grey),
                        const SizedBox(width: 8),
                        Text(
                          group.meeting,
                          style: const TextStyle(color: Colors.black87),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),

                    // Member Activity & Updates Feed
                    if (isJoined) ...[
                      Row(
                        children: [
                          const Icon(Icons.campaign_outlined, color: primaryBlue, size: 22),
                          const SizedBox(width: 8),
                          const Text(
                            'Group Updates & Activity',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Colors.black87,
                            ),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: lightBlueBg,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Text(
                              'Members Only',
                              style: TextStyle(
                                fontSize: 11,
                                color: primaryBlue,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: activities.length,
                        itemBuilder: (context, idx) {
                          final item = activities[idx];
                          return Container(
                            margin: const EdgeInsets.only(bottom: 10),
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: cardBlueBg,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: lightBlueBg),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      item['title']!,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14,
                                        color: Colors.black87,
                                      ),
                                    ),
                                    Text(
                                      item['date']!,
                                      style: const TextStyle(
                                        fontSize: 11,
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  item['desc']!,
                                  style: const TextStyle(
                                    fontSize: 13,
                                    color: Colors.black54,
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 20),
                    ] else ...[
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Row(
                          children: [
                            Icon(Icons.lock_outline, size: 20, color: Colors.grey),
                            SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'Join this group to access member updates, announcements, and activity schedule.',
                                style: TextStyle(fontSize: 12, color: Colors.grey),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],

                    // Action Button
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: isJoined ? Colors.red.shade400 : primaryBlue,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        onPressed: () {
                          setState(() {
                            if (isJoined) {
                              _joinedGroupIds.remove(group.id);
                            } else {
                              _joinedGroupIds.add(group.id);
                            }
                          });
                          setModalState(() {});

                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                isJoined
                                    ? 'Left ${group.name}'
                                    : 'Joined ${group.name} successfully! Activity feed unlocked.',
                              ),
                              duration: const Duration(seconds: 2),
                            ),
                          );
                        },
                        child: Text(
                          isJoined ? 'Leave Group' : 'Join Group',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final groups = _repository.getGroups();

    return ValueListenableBuilder<AppLanguage>(
      valueListenable: LanguageService.instance.currentLanguage,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            title: Text(
              LanguageService.instance.translate('church_groups'),
              style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
            ),
            backgroundColor: Colors.white,
            elevation: 0,
            iconTheme: const IconThemeData(color: Colors.black87),
          ),
          body: ListView.builder(
            padding: const EdgeInsets.all(16.0),
            itemCount: groups.length,
            itemBuilder: (context, index) {
              final group = groups[index];
              final bool isJoined = _joinedGroupIds.contains(group.id);

              return Card(
                elevation: 0,
                color: cardBlueBg,
                margin: const EdgeInsets.only(bottom: 12.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(
                    color: isJoined ? primaryBlue : lightBlueBg,
                    width: isJoined ? 2.0 : 1.5,
                  ),
                ),
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () => _showGroupDetailsModal(group),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: isJoined ? primaryBlue : lightBlueBg,
                          child: Icon(
                            isJoined ? Icons.check : Icons.groups,
                            color: isJoined ? Colors.white : primaryBlue,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    group.name,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      color: Colors.black87,
                                    ),
                                  ),
                                  if (isJoined) ...[
                                    const SizedBox(width: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 8,
                                        vertical: 2,
                                      ),
                                      decoration: BoxDecoration(
                                        color: primaryBlue,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: const Text(
                                        'Joined',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                              const SizedBox(height: 4),
                              Text(
                                group.description,
                                style: const TextStyle(color: Colors.black54, fontSize: 13),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                group.meeting,
                                style: const TextStyle(
                                  color: primaryBlue,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Colors.grey),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}