import 'package:flutter/material.dart';
import '../services/app_repository.dart';

class MassScheduleScreen extends StatelessWidget {
  const MassScheduleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final masses = AppRepository().getMasses();
    return Scaffold(
      appBar: AppBar(title: const Text('Mass Schedule')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: masses.length,
        itemBuilder: (_, i) {
          final mass = masses[i];
          return Card(
            elevation: 0,
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              leading: const CircleAvatar(
                backgroundColor: Color(0xFFF2E3E6),
                child: Icon(Icons.church, color: Color(0xFF7B1E2B)),
              ),
              title: Text('${mass.day} • ${mass.time}', style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${mass.language} • ${mass.church}'),
            ),
          );
        },
      ),
    );
  }
}
