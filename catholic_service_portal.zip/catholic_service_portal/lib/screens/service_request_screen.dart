import 'package:flutter/material.dart';
import '../services/app_repository.dart';

class ServiceRequestScreen extends StatefulWidget {
  final String serviceName;
  const ServiceRequestScreen({super.key, required this.serviceName});

  @override
  State<ServiceRequestScreen> createState() => _ServiceRequestScreenState();
}

class _ServiceRequestScreenState extends State<ServiceRequestScreen> {
  final formKey = GlobalKey<FormState>();
  final details = TextEditingController();
  bool loading = false;

  @override
  void dispose() {
    details.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    if (!formKey.currentState!.validate()) return;
    setState(() => loading = true);
    await Future.delayed(const Duration(milliseconds: 500));
    AppRepository().submitServiceRequest(widget.serviceName, details.text.trim());
    if (!mounted) return;
    setState(() => loading = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Service request submitted successfully.')),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.serviceName)),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Text('Request ${widget.serviceName}', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Enter the information the parish needs to process your request.'),
            const SizedBox(height: 20),
            TextFormField(
              controller: details,
              maxLines: 6,
              decoration: const InputDecoration(labelText: 'Details', hintText: 'Write your request here...'),
              validator: (value) => value == null || value.trim().length < 5 ? 'Please enter more details.' : null,
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: loading ? null : submit,
              icon: const Icon(Icons.send),
              label: Text(loading ? 'Submitting...' : 'Submit Request'),
            ),
          ],
        ),
      ),
    );
  }
}
