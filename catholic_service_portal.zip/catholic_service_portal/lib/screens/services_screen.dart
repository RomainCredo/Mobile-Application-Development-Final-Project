import 'package:flutter/material.dart';
import '../services/app_repository.dart';
import '../widgets/portal_card.dart';
import 'service_request_screen.dart';
import 'appointment_screen.dart';
import 'groups_screen.dart';

class ServicesScreen extends StatelessWidget {
  const ServicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final services = AppRepository().getServices();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('Church Services', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('Request a service or get information from the parish.'),
          const SizedBox(height: 20),
          ...services.map(
            (service) => PortalCard(
              icon: service.icon,
              title: service.title,
              subtitle: service.description,
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => ServiceRequestScreen(serviceName: service.title)),
              ),
            ),
          ),
          const SizedBox(height: 8),
          PortalCard(
            icon: Icons.person_search_outlined,
            title: 'Priest Appointment',
            subtitle: 'Request spiritual guidance or a meeting',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AppointmentScreen())),
          ),
          PortalCard(
            icon: Icons.groups_outlined,
            title: 'Church Groups',
            subtitle: 'Explore parish ministries and groups',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GroupsScreen())),
          ),
        ],
      ),
    );
  }
}
