import 'package:flutter/material.dart';
import '../services/language_service.dart';
import 'home_screen.dart';
import 'groups_screen.dart';
import 'liturgy_screen.dart';
import 'profile_screen.dart';

const primaryBlue = Color(0xFF1E88E5);
const lightBlueBg = Color(0xFFE3F2FD);

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    HomeScreen(),
    LiturgyScreen(),
    GroupsScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: LanguageService.instance.currentLanguage,
      builder: (context, _, __) {
        final lang = LanguageService.instance;

        return Scaffold(
          body: IndexedStack(
            index: _currentIndex,
            children: _screens,
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _currentIndex,
            onDestinationSelected: (index) {
              setState(() {
                _currentIndex = index;
              });
            },
            backgroundColor: Colors.white,
            indicatorColor: lightBlueBg,
            elevation: 8,
            destinations: [
              NavigationDestination(
                icon: const Icon(Icons.home_outlined),
                selectedIcon: const Icon(Icons.home, color: primaryBlue),
                label: lang.translate('home'),
              ),
              const NavigationDestination(
                icon: Icon(Icons.menu_book_outlined),
                selectedIcon: Icon(Icons.menu_book, color: primaryBlue),
                label: 'Liturgy',
              ),
              NavigationDestination(
                icon: const Icon(Icons.groups_outlined),
                selectedIcon: const Icon(Icons.groups, color: primaryBlue),
                label: lang.translate('groups'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.person_outline),
                selectedIcon: const Icon(Icons.person, color: primaryBlue),
                label: lang.translate('profile'),
              ),
            ],
          ),
        );
      },
    );
  }
}