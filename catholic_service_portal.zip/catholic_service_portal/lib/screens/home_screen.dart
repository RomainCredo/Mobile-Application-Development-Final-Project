import 'package:flutter/material.dart';
import '../services/language_service.dart';
import 'community_screen.dart';
import 'donations_screen.dart';
import 'groups_screen.dart';

// Blue & White Palette Constants
const primaryBlue = Color(0xFF1E88E5);
const secondaryBlue = Color(0xFF1565C0);
const lightBlueBg = Color(0xFFE3F2FD);
const cardBlueBg = Color(0xFFF0F7FF);

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Dynamic Mass Schedule Data
  String sundayMassTime = '07:00 AM | 09:00 AM | 11:00 AM';
  String weekdayMassTime = 'Monday - Saturday at 06:30 AM';
  String confessionTime = 'Saturdays at 04:00 PM';

  void _showEditScheduleModal() {
    final sundayController = TextEditingController(text: sundayMassTime);
    final weekdayController = TextEditingController(text: weekdayMassTime);
    final confessionController = TextEditingController(text: confessionTime);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            top: 20,
            left: 20,
            right: 20,
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Icon(Icons.edit_calendar, color: primaryBlue, size: 26),
                  SizedBox(width: 10),
                  Text(
                    'Update Mass Schedule',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                ],
              ),
              const Divider(height: 24),
              TextField(
                controller: sundayController,
                decoration: const InputDecoration(
                  labelText: 'Sunday Mass Times',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.access_time_filled, color: primaryBlue),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: weekdayController,
                decoration: const InputDecoration(
                  labelText: 'Weekday Mass Times',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.wb_sunny_outlined, color: primaryBlue),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: confessionController,
                decoration: const InputDecoration(
                  labelText: 'Confession Times',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.volunteer_activism_outlined, color: primaryBlue),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryBlue,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  onPressed: () {
                    setState(() {
                      sundayMassTime = sundayController.text;
                      weekdayMassTime = weekdayController.text;
                      confessionTime = confessionController.text;
                    });
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Mass schedule updated successfully!'),
                      ),
                    );
                  },
                  child: const Text(
                    'Save Schedule Changes',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showRequestsDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.assignment_outlined, color: primaryBlue, size: 28),
                  const SizedBox(width: 12),
                  Text(
                    LanguageService.instance.translate('my_requests'),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const Divider(height: 24),
              ListTile(
                leading: const CircleAvatar(backgroundColor: lightBlueBg, child: Icon(Icons.water_drop, color: primaryBlue)),
                title: const Text('Baptism Request'),
                subtitle: const Text('Status: Pending Approval'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {},
              ),
              ListTile(
                leading: const CircleAvatar(backgroundColor: lightBlueBg, child: Icon(Icons.favorite, color: primaryBlue)),
                title: const Text('Matrimony (Marriage) Intent'),
                subtitle: const Text('Status: In Progress'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {},
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryBlue,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('New Request form opened')),
                    );
                  },
                  icon: const Icon(Icons.add, color: Colors.white),
                  label: const Text('Submit New Request', style: TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showAppointmentsDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.calendar_month_outlined, color: primaryBlue, size: 28),
                  const SizedBox(width: 12),
                  Text(
                    LanguageService.instance.translate('my_appointments'),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const Divider(height: 24),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: cardBlueBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: lightBlueBg),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.event, color: primaryBlue),
                    SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Priest Consultation', style: TextStyle(fontWeight: FontWeight.bold)),
                        Text('Friday, 03:00 PM • Father Joseph', style: TextStyle(color: Colors.black54, fontSize: 13)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryBlue,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Book Appointment dialog opened')),
                    );
                  },
                  child: const Text('Book New Appointment', style: TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showCertificatesDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.description_outlined, color: primaryBlue, size: 28),
                  const SizedBox(width: 12),
                  Text(
                    LanguageService.instance.translate('my_certificates'),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const Divider(height: 24),
              ListTile(
                leading: const Icon(Icons.workspace_premium, color: primaryBlue),
                title: const Text('Baptism Certificate'),
                subtitle: const Text('Issued: Oct 2023'),
                trailing: IconButton(
                  icon: const Icon(Icons.download, color: primaryBlue),
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Downloading Baptism Certificate...')),
                    );
                  },
                ),
              ),
              ListTile(
                leading: const Icon(Icons.workspace_premium, color: primaryBlue),
                title: const Text('Confirmation Certificate'),
                subtitle: const Text('Issued: Nov 2024'),
                trailing: IconButton(
                  icon: const Icon(Icons.download, color: primaryBlue),
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Downloading Confirmation Certificate...')),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: LanguageService.instance.currentLanguage,
      builder: (context, _, __) {
        final langService = LanguageService.instance;

        return Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            backgroundColor: Colors.white,
            elevation: 0,
            title: Row(
              children: [
                const CircleAvatar(
                  backgroundColor: lightBlueBg,
                  child: Icon(Icons.church, color: primaryBlue),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      langService.translate('parishioner'),
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                    const Text(
                      'Catholic Service Portal',
                      style: TextStyle(
                        fontSize: 18,
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.notifications_none, color: Colors.black87),
                onPressed: () {},
              ),
            ],
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Welcome Banner
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [primaryBlue, secondaryBlue],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: primaryBlue.withOpacity(0.2),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        langService.translate('welcome_back'),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        langService.translate('welcome_sub'),
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // Quick Services Title
                Text(
                  langService.translate('quick_services'),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 12),

                // Expanded Quick Access Grid (2 Rows x 3 Columns)
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 3,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.1,
                  children: [
                    _buildQuickAction(
                      Icons.assignment_outlined,
                      langService.translate('my_requests'),
                      () => _showRequestsDialog(context),
                    ),
                    _buildQuickAction(
                      Icons.calendar_month_outlined,
                      langService.translate('my_appointments'),
                      () => _showAppointmentsDialog(context),
                    ),
                    _buildQuickAction(
                      Icons.groups_outlined,
                      langService.translate('church_groups'),
                      () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const GroupsScreen()),
                        );
                      },
                    ),
                    _buildQuickAction(
                      Icons.description_outlined,
                      langService.translate('my_certificates'),
                      () => _showCertificatesDialog(context),
                    ),
                    _buildQuickAction(
                      Icons.volunteer_activism_outlined,
                      'Tithes & Intentions',
                      () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const DonationsScreen()),
                        );
                      },
                    ),
                    _buildQuickAction(
                      Icons.home_work_outlined,
                      'Imiryango Remezo',
                      () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const CommunityScreen()),
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // Upcoming Mass Schedule Header with Edit Option
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      langService.translate('upcoming_mass'),
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.edit_outlined, color: primaryBlue, size: 20),
                      tooltip: 'Update Schedule',
                      onPressed: _showEditScheduleModal,
                    ),
                  ],
                ),
                const SizedBox(height: 8),

                // Interactive Schedule Card
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: cardBlueBg,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: lightBlueBg, width: 1.5),
                  ),
                  child: Column(
                    children: [
                      _ScheduleTile(
                        day: 'Sunday Mass',
                        time: sundayMassTime,
                        icon: Icons.access_time_filled,
                      ),
                      const Divider(height: 20),
                      _ScheduleTile(
                        day: 'Weekday Mass',
                        time: weekdayMassTime,
                        icon: Icons.wb_sunny_outlined,
                      ),
                      const Divider(height: 20),
                      _ScheduleTile(
                        day: 'Confession',
                        time: confessionTime,
                        icon: Icons.volunteer_activism_outlined,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // Announcements Section
                Text(
                  langService.translate('latest_announcements'),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: cardBlueBg,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: lightBlueBg, width: 1.5),
                  ),
                  child: Row(
                    children: [
                      const CircleAvatar(
                        backgroundColor: primaryBlue,
                        child: Icon(Icons.campaign, color: Colors.white),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Parish Community Meeting',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Join us this Sunday after the 09:00 AM Mass for our monthly gathering.',
                              style: TextStyle(
                                fontSize: 13,
                                color: Colors.grey.shade700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildQuickAction(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: lightBlueBg,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: primaryBlue, size: 24),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ScheduleTile extends StatelessWidget {
  final String day;
  final String time;
  final IconData icon;

  const _ScheduleTile({
    required this.day,
    required this.time,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: primaryBlue, size: 22),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                day,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: Colors.black87,
                ),
              ),
              Text(
                time,
                style: const TextStyle(
                  fontSize: 13,
                  color: Colors.black54,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}