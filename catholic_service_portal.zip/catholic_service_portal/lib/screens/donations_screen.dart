import 'package:flutter/material.dart';

const primaryBlue = Color(0xFF1E88E5);
const lightBlueBg = Color(0xFFE3F2FD);
const cardBlueBg = Color(0xFFF0F7FF);

class DonationsScreen extends StatefulWidget {
  const DonationsScreen({super.key});

  @override
  State<DonationsScreen> createState() => _DonationsScreenState();
}

class _DonationsScreenState extends State<DonationsScreen> {
  String _selectedCategory = 'Tithe (Amaturo)';
  String _paymentProvider = 'MTN Mobile Money';
  final _amountController = TextEditingController();
  final _phoneController = TextEditingController();
  final _intentionNoteController = TextEditingController();
  bool _isProcessing = false;

  final List<String> _categories = [
    'Tithe (Amaturo)',
    'Sunday Offertory',
    'Mass Intention Request',
    'Parish Building Fund',
  ];

  void _processPayment() async {
    if (_amountController.text.isEmpty || _phoneController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter amount and phone number')),
      );
      return;
    }

    setState(() => _isProcessing = true);

    await Future.delayed(const Duration(seconds: 2));

    if (mounted) {
      setState(() => _isProcessing = false);
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(
            children: [
              Icon(Icons.check_circle, color: Colors.green, size: 28),
              SizedBox(width: 10),
              Text('Payment Prompt Sent'),
            ],
          ),
          content: Text(
            'A payment prompt of ${_amountController.text} RWF has been sent to ${_phoneController.text}. Please accept on your phone via $_paymentProvider to complete.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _amountController.clear();
                _phoneController.clear();
                _intentionNoteController.clear();
              },
              child: const Text('OK', style: TextStyle(color: primaryBlue)),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Offertory & Mass Intentions', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [primaryBlue, Color(0xFF1565C0)]),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  const CircleAvatar(backgroundColor: Colors.white24, child: Icon(Icons.volunteer_activism, color: Colors.white)),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Support Your Parish', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Text(
                          'Give tithes, offertory, or book Mass intentions securely via MoMo.',
                          style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 13),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            DropdownButtonFormField<String>(
              value: _selectedCategory,
              decoration: const InputDecoration(
                labelText: 'Contribution Type',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.payments_outlined, color: primaryBlue),
              ),
              items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
              onChanged: (val) => setState(() => _selectedCategory = val!),
            ),
            const SizedBox(height: 16),

            if (_selectedCategory == 'Mass Intention Request') ...[
              TextField(
                controller: _intentionNoteController,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'Mass Intention (e.g., Thanksgiving, Repose of Soul)',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.church, color: primaryBlue),
                ),
              ),
              const SizedBox(height: 16),
            ],

            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Amount (RWF)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.money, color: primaryBlue),
              ),
            ),
            const SizedBox(height: 16),

            DropdownButtonFormField<String>(
              value: _paymentProvider,
              decoration: const InputDecoration(
                labelText: 'Mobile Money Provider',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.phone_android, color: primaryBlue),
              ),
              items: ['MTN Mobile Money', 'Airtel Money']
                  .map((p) => DropdownMenuItem(value: p, child: Text(p)))
                  .toList(),
              onChanged: (val) => setState(() => _paymentProvider = val!),
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'MoMo Number (e.g., 078XXXXXXX)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.phone, color: primaryBlue),
              ),
            ),
            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryBlue,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: _isProcessing ? null : _processPayment,
                child: _isProcessing
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text('Send MoMo Payment', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}