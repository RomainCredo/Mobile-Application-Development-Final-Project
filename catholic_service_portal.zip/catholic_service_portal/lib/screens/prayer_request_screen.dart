import 'package:flutter/material.dart';
import '../services/app_repository.dart';

class PrayerRequestScreen extends StatefulWidget {
  const PrayerRequestScreen({super.key});

  @override
  State<PrayerRequestScreen> createState() => _PrayerRequestScreenState();
}

class _PrayerRequestScreenState extends State<PrayerRequestScreen> {
  final controller = TextEditingController();
  final formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void submit() {
    if (!formKey.currentState!.validate()) return;
    AppRepository().submitPrayerRequest(controller.text.trim());
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Your prayer request has been submitted.')),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Prayer Request')),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const Text('Share a Prayer Intention', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Your request can later be stored securely in Firebase.'),
            const SizedBox(height: 20),
            TextFormField(
              controller: controller,
              maxLines: 7,
              decoration: const InputDecoration(
                labelText: 'Prayer intention',
                hintText: 'Write your prayer request...',
              ),
              validator: (v) => v == null || v.trim().isEmpty ? 'Please enter your prayer request.' : null,
            ),
            const SizedBox(height: 20),
            FilledButton.icon(onPressed: submit, icon: const Icon(Icons.send), label: const Text('Send Prayer Request')),
          ],
        ),
      ),
    );
  }
}
