import 'package:flutter/material.dart';
import '../services/firestore_service.dart';

const primaryBlue = Color(0xFF1E88E5);

class SacramentRequestModal extends StatefulWidget {
  const SacramentRequestModal({super.key});

  @override
  State<SacramentRequestModal> createState() => _SacramentRequestModalState();
}

class _SacramentRequestModalState extends State<SacramentRequestModal> {
  final _formKey = GlobalKey<FormState>();
  String _selectedType = 'Baptism';
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _notesController = TextEditingController();
  bool _isSubmitting = false;

  final List<String> _requestTypes = [
    'Baptism',
    'First Holy Communion',
    'Confirmation',
    'Matrimony (Marriage)',
  ];

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSubmitting = true);
    try {
      await FirestoreService.instance.submitSacramentRequest(
        requestType: _selectedType,
        applicantName: _nameController.text.trim(),
        contactPhone: _phoneController.text.trim(),
        notes: _notesController.text.trim(),
      );

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Sacrament request submitted successfully!')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error submitting request: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        top: 24,
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Submit Sacrament Request',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87),
              ),
              const Divider(height: 24),
              DropdownButtonFormField<String>(
                value: _selectedType,
                decoration: const InputDecoration(
                  labelText: 'Sacrament Type',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.water_drop_outlined, color: primaryBlue),
                ),
                items: _requestTypes
                    .map((type) => DropdownMenuItem(value: type, child: Text(type)))
                    .toList(),
                onChanged: (val) => setState(() => _selectedType = val!),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Applicant Full Name',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person_outline, color: primaryBlue),
                ),
                validator: (val) => val == null || val.isEmpty ? 'Enter applicant name' : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'Contact Phone Number',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.phone_outlined, color: primaryBlue),
                ),
                validator: (val) => val == null || val.isEmpty ? 'Enter contact phone' : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _notesController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Additional Details or Notes',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.note_alt_outlined, color: primaryBlue),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryBlue,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: _isSubmitting ? null : _submitForm,
                  child: _isSubmitting
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('Submit Request', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}