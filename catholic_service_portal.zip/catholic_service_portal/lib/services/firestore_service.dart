
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  static final FirestoreService instance = FirestoreService._internal();
  FirestoreService._internal();

  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String? get currentUserId => _auth.currentUser?.uid;

  // --- MASS SCHEDULES ---
  Stream<DocumentSnapshot<Map<String, dynamic>>> getMassScheduleStream() {
    return _db.collection('settings').doc('mass_schedule').snapshots();
  }

  Future<void> updateMassSchedule({
    required String sunday,
    required String weekday,
    required String confession,
  }) async {
    await _db.collection('settings').doc('mass_schedule').set({
      'sunday': sunday,
      'weekday': weekday,
      'confession': confession,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  // --- SACRAMENT REQUESTS ---
  Future<void> submitSacramentRequest({
    required String requestType,
    required String applicantName,
    required String contactPhone,
    required String notes,
  }) async {
    if (currentUserId == null) return;

    await _db.collection('sacrament_requests').add({
      'userId': currentUserId,
      'userEmail': _auth.currentUser?.email ?? '',
      'requestType': requestType,
      'applicantName': applicantName,
      'contactPhone': contactPhone,
      'notes': notes,
      'status': 'Pending',
      'submittedAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> getUserRequestsStream() {
    return _db
        .collection('sacrament_requests')
        .where('userId', isEqualTo: currentUserId ?? '')
        .snapshots();
  }

  // --- CHURCH GROUPS MEMBERSHIP ---
  Future<void> toggleGroupMembership(String groupId, bool join) async {
    if (currentUserId == null) return;

    final userRef = _db.collection('users').doc(currentUserId);
    if (join) {
      await userRef.set({
        'joinedGroups': FieldValue.arrayUnion([groupId]),
      }, SetOptions(merge: true));
    } else {
      await userRef.set({
        'joinedGroups': FieldValue.arrayRemove([groupId]),
      }, SetOptions(merge: true));
    }
  }
}