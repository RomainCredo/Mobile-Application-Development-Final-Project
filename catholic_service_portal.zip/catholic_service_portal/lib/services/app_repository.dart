import 'package:flutter/material.dart';
import '../models/app_models.dart';

class AppRepository {
  // Replace these mock methods with Firebase Auth/Firestore methods.
  List<Mass> getMasses() => const [
        Mass(id: 'm1', day: 'Sunday', time: '07:00 AM', language: 'Kinyarwanda', church: 'Main Parish'),
        Mass(id: 'm2', day: 'Sunday', time: '09:00 AM', language: 'English', church: 'Main Parish'),
        Mass(id: 'm3', day: 'Sunday', time: '11:00 AM', language: 'Kinyarwanda', church: 'Main Parish'),
        Mass(id: 'm4', day: 'Wednesday', time: '06:00 PM', language: 'Kinyarwanda', church: 'Main Parish'),
        Mass(id: 'm5', day: 'Friday', time: '06:00 PM', language: 'English', church: 'Main Parish'),
      ];

  List<ParishEvent> getEvents() => const [
        ParishEvent(
          id: 'e1',
          title: 'Youth Prayer Evening',
          date: '05 Oct 2026',
          time: '05:00 PM',
          location: 'Parish Hall',
          description: 'An evening of prayer, music and fellowship for young people.',
        ),
        ParishEvent(
          id: 'e2',
          title: 'Bible Study',
          date: '08 Oct 2026',
          time: '04:00 PM',
          location: 'Meeting Room 1',
          description: 'Weekly Bible study and reflection session.',
        ),
        ParishEvent(
          id: 'e3',
          title: 'Parish Community Day',
          date: '18 Oct 2026',
          time: '09:00 AM',
          location: 'Parish Grounds',
          description: 'A community gathering with service activities and fellowship.',
        ),
      ];

  List<ChurchGroup> getGroups() => const [
        ChurchGroup(
          id: 'g1',
          name: 'Catholic Youth',
          description: 'Faith, friendship, leadership and service for young Catholics.',
          meeting: 'Every Saturday at 3:00 PM',
        ),
        ChurchGroup(
          id: 'g2',
          name: 'Choir',
          description: 'Serving the liturgy through music and singing.',
          meeting: 'Every Thursday at 5:00 PM',
        ),
        ChurchGroup(
          id: 'g3',
          name: 'Catechists',
          description: 'Supporting catechesis and faith formation.',
          meeting: 'First Sunday of every month',
        ),
      ];

  List<ServiceItem> getServices() => [
        const ServiceItem(id: 's1', title: 'Baptism', description: 'Request baptism information or registration.', icon: Icons.water_drop_outlined),
        const ServiceItem(id: 's2', title: 'Confirmation', description: 'Information and registration for Confirmation.', icon: Icons.auto_awesome_outlined),
        const ServiceItem(id: 's3', title: 'First Communion', description: 'First Communion preparation and requests.', icon: Icons.church_outlined),
        const ServiceItem(id: 's4', title: 'Marriage', description: 'Marriage preparation and appointment requests.', icon: Icons.favorite_border),
        const ServiceItem(id: 's5', title: 'Confession', description: 'Request a confession appointment.', icon: Icons.volunteer_activism_outlined),
        const ServiceItem(id: 's6', title: 'Funeral Service', description: 'Contact the parish for funeral arrangements.', icon: Icons.local_florist_outlined),
      ];

  void submitPrayerRequest(String request) {
    // TODO: Save to Firestore collection: prayer_requests
  }

  void submitAppointment(String purpose, String date, String time) {
    // TODO: Save to Firestore collection: appointments
  }

  void submitServiceRequest(String service, String details) {
    // TODO: Save to Firestore collection: sacrament_requests
  }
}