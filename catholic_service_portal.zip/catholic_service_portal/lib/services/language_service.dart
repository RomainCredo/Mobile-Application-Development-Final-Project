import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum AppLanguage { english, kinyarwanda, french, latin }

class LanguageService {
  static final LanguageService instance = LanguageService._();
  LanguageService._();

  final ValueNotifier<AppLanguage> currentLanguage = ValueNotifier(AppLanguage.english);

  // Initialize saved language preference on app startup
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    final savedLangCode = prefs.getString('selected_language');
    if (savedLangCode != null) {
      currentLanguage.value = AppLanguage.values.firstWhere(
        (e) => e.name == savedLangCode,
        orElse: () => AppLanguage.english,
      );
    }
  }

  Future<void> setLanguage(AppLanguage lang) async {
    currentLanguage.value = lang;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('selected_language', lang.name);
  }

  String translate(String key) {
    return _localizedValues[currentLanguage.value]?[key] ??
        _localizedValues[AppLanguage.english]![key] ??
        key;
  }

  static const Map<AppLanguage, Map<String, String>> _localizedValues = {
    AppLanguage.english: {
      'home': 'Home',
      'groups': 'Groups',
      'profile': 'Profile',
      'my_profile': 'My Profile',
      'parishioner': 'Parishioner',
      'my_requests': 'My Requests',
      'my_appointments': 'My Appointments',
      'my_certificates': 'My Certificates',
      'settings': 'Settings',
      'language': 'Language',
      'select_language': 'Select Language',
      'notifications': 'Notifications',
      'app_version': 'App Version',
      'church_groups': 'Church Groups',
      'quick_services': 'Quick Services',
      'upcoming_mass': 'Upcoming Mass Schedule',
      'latest_announcements': 'Latest Announcements',
      'welcome_back': 'Welcome Back! 🙏',
      'welcome_sub': 'Stay connected with your parish community and services.',
      'logout': 'Sign Out',
      'close': 'Close',
    },
    AppLanguage.kinyarwanda: {
      'home': 'Ahabanza',
      'groups': 'Amatsinda',
      'profile': 'Umwirondoro',
      'my_profile': 'Umwirondoro Wanjye',
      'parishioner': 'Umukristu',
      'my_requests': 'Ibisabe Byanjye',
      'my_appointments': 'Guhura n\'Padiri',
      'my_certificates': 'Ibyangombwa Byanjye',
      'settings': 'Igenamiterere',
      'language': 'Ururimi',
      'select_language': 'Hitamo Ururimi',
      'notifications': 'Omenyeshwa',
      'app_version': 'Verisiyo ya App',
      'church_groups': 'Amatsinda y\'Ekleziya',
      'quick_services': 'Services Zihuse',
      'upcoming_mass': 'Gahunda y\'Misa',
      'latest_announcements': 'Amatangazo',
      'welcome_back': 'Murakaza Neza! 🙏',
      'welcome_sub': 'Komeza ube hafi ya paroisse yawe n\'ibikorwa byayo.',
      'logout': 'Sohoka',
      'close': 'Funga',
    },
    AppLanguage.french: {
      'home': 'Accueil',
      'groups': 'Groupes',
      'profile': 'Profil',
      'my_profile': 'Mon Profil',
      'parishioner': 'Paroissien',
      'my_requests': 'Mes Demandes',
      'my_appointments': 'Mes Rendez-vous',
      'my_certificates': 'Mes Certificats',
      'settings': 'Paramètres',
      'language': 'Langue',
      'select_language': 'Choisir la langue',
      'notifications': 'Notifications',
      'app_version': 'Version de l\'application',
      'church_groups': 'Groupes paroissiaux',
      'quick_services': 'Services Rapides',
      'upcoming_mass': 'Horaire des Messes',
      'latest_announcements': 'Dernières Annonces',
      'welcome_back': 'Bienvenue! 🙏',
      'welcome_sub': 'Restez connecté avec votre communauté paroissiale.',
      'logout': 'Se Déconnecter',
      'close': 'Fermer',
    },
    AppLanguage.latin: {
      'home': 'Domus',
      'groups': 'Coetus',
      'profile': 'Profile',
      'my_profile': 'Profile Meum',
      'parishioner': 'Parochianus',
      'my_requests': 'Petitiones Meae',
      'my_appointments': 'Conventus Mei',
      'my_certificates': 'Testimonia Mea',
      'settings': 'Configuratio',
      'language': 'Lingua',
      'select_language': 'Elige Linguam',
      'notifications': 'Notificationes',
      'app_version': 'Versio Applicationis',
      'church_groups': 'Coetus Ecclesiae',
      'quick_services': 'Ministeria Celeria',
      'upcoming_mass': 'Ordo Missarum',
      'latest_announcements': 'Nuntii Novissimi',
      'welcome_back': 'Ave Maria / Salve! 🙏',
      'welcome_sub': 'Mane coniunctus cum communitate paroeciali tua.',
      'logout': 'Discedere',
      'close': 'Claudere',
    },
  };
}