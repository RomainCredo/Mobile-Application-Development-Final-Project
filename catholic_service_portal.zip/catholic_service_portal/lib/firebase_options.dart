import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }

    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;

      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyCbtxtxv_iBkAgi84CIhhiQ04QE1ETYbgY',
    appId: '1:26179333159:web:de9c51fe83cf03f4c5b202',
    messagingSenderId: '26179333159',
    projectId: 'catholic-service-portal',
    authDomain: 'catholic-service-portal.firebaseapp.com',
    storageBucket: 'catholic-service-portal.firebasestorage.app',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAvlPFR_Q_9BZJjRCM5uyQ1D3JbqhC6Bv0',
    appId: '1:26179333159:android:de9535f3f84b4cf1c5b202',
    messagingSenderId: '26179333159',
    projectId: 'catholic-service-portal',
    storageBucket: 'catholic-service-portal.firebasestorage.app',
  );
}