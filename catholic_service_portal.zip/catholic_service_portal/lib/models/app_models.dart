import 'package:flutter/material.dart';

class Mass {
  final String id;
  final String day;
  final String time;
  final String language;
  final String church;

  const Mass({
    required this.id,
    required this.day,
    required this.time,
    required this.language,
    required this.church,
  });
}

class ParishEvent {
  final String id;
  final String title;
  final String date;
  final String time;
  final String location;
  final String description;

  const ParishEvent({
    required this.id,
    required this.title,
    required this.date,
    required this.time,
    required this.location,
    required this.description,
  });
}

class ChurchGroup {
  final String id;
  final String name;
  final String description;
  final String meeting;

  const ChurchGroup({
    required this.id,
    required this.name,
    required this.description,
    required this.meeting,
  });
}

class ServiceItem {
  final String id;
  final String title;
  final String description;
  final IconData icon;

  const ServiceItem({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
  });
}
