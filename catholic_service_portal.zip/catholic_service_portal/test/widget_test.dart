import 'package:flutter_test/flutter_test.dart';
import 'package:catholic_service_portal/main.dart';

void main() {
  testWidgets('Catholic Service Portal loads', (WidgetTester tester) async {
    await tester.pumpWidget(
      const CatholicServicePortalApp(),
    );

    expect(find.text('Welcome Back'), findsOneWidget);
  });
}