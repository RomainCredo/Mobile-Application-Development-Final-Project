# Catholic Service Portal

A Flutter mobile application prototype for parishioners and parish administrators.

## Included
- Welcome/home dashboard
- Mass schedule
- Sacrament services
- Appointment request form
- Prayer request form
- Parish events
- Church groups
- Daily Gospel/prayer section
- User profile
- Request tracking
- Local mock data so the app runs before Firebase is connected

## Firebase
Firebase is intentionally NOT configured in this starter project. Connect Firebase yourself and replace the methods in `lib/services/app_repository.dart` with Firestore/Auth operations.

Suggested Firestore collections:
- users
- masses
- sacraments
- sacrament_requests
- appointments
- prayer_requests
- events
- groups
- announcements

## Run
flutter pub get
flutter run

## Suggested next steps
1. Add Firebase Core and Firebase Auth.
2. Add Cloud Firestore.
3. Create login/register screens.
4. Replace MockAppRepository with FirestoreAppRepository.
5. Add Firebase Storage for profile images if needed.
6. Add push notifications with Firebase Cloud Messaging.
